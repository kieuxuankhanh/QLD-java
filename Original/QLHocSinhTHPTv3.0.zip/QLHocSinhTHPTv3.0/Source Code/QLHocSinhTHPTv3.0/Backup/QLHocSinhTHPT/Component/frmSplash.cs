using System;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using DevComponents.DotNetBar;

namespace QLHocSinhTHPT.Component
{
    public partial class frmSplash : Office2007Form
    {
        #region Constructor
        public frmSplash()
        {
            InitializeComponent();
        }
        #endregion
    }
}