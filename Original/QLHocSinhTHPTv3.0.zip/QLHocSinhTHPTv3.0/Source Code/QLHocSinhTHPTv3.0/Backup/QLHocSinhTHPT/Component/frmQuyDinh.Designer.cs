﻿namespace QLHocSinhTHPT.Component
{
    partial class frmQuyDinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControlQuyDinh = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanelSiSo = new DevComponents.DotNetBar.TabControlPanel();
            this.txtSiSoCanTren = new DevComponents.Editors.IntegerInput();
            this.labelX02 = new DevComponents.DotNetBar.LabelX();
            this.txtSiSoCanDuoi = new DevComponents.Editors.IntegerInput();
            this.labelX01 = new DevComponents.DotNetBar.LabelX();
            this.tabItemSiSo = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanelTruong = new DevComponents.DotNetBar.TabControlPanel();
            this.txtDiaChiTruong = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtTenTruong = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX07 = new DevComponents.DotNetBar.LabelX();
            this.labelX06 = new DevComponents.DotNetBar.LabelX();
            this.tabItemTruong = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanelThangDiem = new DevComponents.DotNetBar.TabControlPanel();
            this.ckbThang100 = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.ckbThang10 = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.labelX05 = new DevComponents.DotNetBar.LabelX();
            this.tabItemThangDiem = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanelDoTuoi = new DevComponents.DotNetBar.TabControlPanel();
            this.txtDoTuoiCanTren = new DevComponents.Editors.IntegerInput();
            this.labelX04 = new DevComponents.DotNetBar.LabelX();
            this.txtDoTuoiCanDuoi = new DevComponents.Editors.IntegerInput();
            this.labelX03 = new DevComponents.DotNetBar.LabelX();
            this.tabItemDoTuoi = new DevComponents.DotNetBar.TabItem(this.components);
            this.btnDongY = new DevComponents.DotNetBar.ButtonX();
            this.btnHuyBo = new DevComponents.DotNetBar.ButtonX();
            this.panelBottom = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.tabControlQuyDinh)).BeginInit();
            this.tabControlQuyDinh.SuspendLayout();
            this.tabControlPanelSiSo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSiSoCanTren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSiSoCanDuoi)).BeginInit();
            this.tabControlPanelTruong.SuspendLayout();
            this.tabControlPanelThangDiem.SuspendLayout();
            this.tabControlPanelDoTuoi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtDoTuoiCanTren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDoTuoiCanDuoi)).BeginInit();
            this.panelBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlQuyDinh
            // 
            this.tabControlQuyDinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(217)))), ((int)(((byte)(247)))));
            this.tabControlQuyDinh.CanReorderTabs = true;
            this.tabControlQuyDinh.Controls.Add(this.tabControlPanelSiSo);
            this.tabControlQuyDinh.Controls.Add(this.tabControlPanelThangDiem);
            this.tabControlQuyDinh.Controls.Add(this.tabControlPanelDoTuoi);
            this.tabControlQuyDinh.Controls.Add(this.tabControlPanelTruong);
            this.tabControlQuyDinh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlQuyDinh.Location = new System.Drawing.Point(0, 0);
            this.tabControlQuyDinh.Name = "tabControlQuyDinh";
            this.tabControlQuyDinh.SelectedTabFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlQuyDinh.SelectedTabIndex = 0;
            this.tabControlQuyDinh.Size = new System.Drawing.Size(344, 148);
            this.tabControlQuyDinh.Style = DevComponents.DotNetBar.eTabStripStyle.Office2007Document;
            this.tabControlQuyDinh.TabIndex = 0;
            this.tabControlQuyDinh.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControlQuyDinh.Tabs.Add(this.tabItemSiSo);
            this.tabControlQuyDinh.Tabs.Add(this.tabItemDoTuoi);
            this.tabControlQuyDinh.Tabs.Add(this.tabItemThangDiem);
            this.tabControlQuyDinh.Tabs.Add(this.tabItemTruong);
            // 
            // tabControlPanelSiSo
            // 
            this.tabControlPanelSiSo.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.tabControlPanelSiSo.Controls.Add(this.txtSiSoCanTren);
            this.tabControlPanelSiSo.Controls.Add(this.labelX02);
            this.tabControlPanelSiSo.Controls.Add(this.txtSiSoCanDuoi);
            this.tabControlPanelSiSo.Controls.Add(this.labelX01);
            this.tabControlPanelSiSo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanelSiSo.Location = new System.Drawing.Point(0, 23);
            this.tabControlPanelSiSo.Name = "tabControlPanelSiSo";
            this.tabControlPanelSiSo.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanelSiSo.Size = new System.Drawing.Size(344, 125);
            this.tabControlPanelSiSo.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tabControlPanelSiSo.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tabControlPanelSiSo.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanelSiSo.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanelSiSo.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanelSiSo.Style.GradientAngle = 90;
            this.tabControlPanelSiSo.TabIndex = 0;
            this.tabControlPanelSiSo.TabItem = this.tabItemSiSo;
            // 
            // txtSiSoCanTren
            // 
            // 
            // 
            // 
            this.txtSiSoCanTren.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtSiSoCanTren.Location = new System.Drawing.Point(190, 70);
            this.txtSiSoCanTren.MaxValue = 100;
            this.txtSiSoCanTren.MinValue = 10;
            this.txtSiSoCanTren.Name = "txtSiSoCanTren";
            this.txtSiSoCanTren.ShowUpDown = true;
            this.txtSiSoCanTren.Size = new System.Drawing.Size(120, 20);
            this.txtSiSoCanTren.TabIndex = 2;
            this.txtSiSoCanTren.Value = 10;
            // 
            // labelX02
            // 
            this.labelX02.BackColor = System.Drawing.Color.Transparent;
            this.labelX02.Location = new System.Drawing.Point(30, 70);
            this.labelX02.Name = "labelX02";
            this.labelX02.Size = new System.Drawing.Size(143, 20);
            this.labelX02.TabIndex = 0;
            this.labelX02.Text = "Sỉ số tối đa trong một lớp:";
            // 
            // txtSiSoCanDuoi
            // 
            // 
            // 
            // 
            this.txtSiSoCanDuoi.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtSiSoCanDuoi.Location = new System.Drawing.Point(190, 30);
            this.txtSiSoCanDuoi.MaxValue = 100;
            this.txtSiSoCanDuoi.MinValue = 10;
            this.txtSiSoCanDuoi.Name = "txtSiSoCanDuoi";
            this.txtSiSoCanDuoi.ShowUpDown = true;
            this.txtSiSoCanDuoi.Size = new System.Drawing.Size(120, 20);
            this.txtSiSoCanDuoi.TabIndex = 1;
            this.txtSiSoCanDuoi.Value = 10;
            // 
            // labelX01
            // 
            this.labelX01.BackColor = System.Drawing.Color.Transparent;
            this.labelX01.Location = new System.Drawing.Point(30, 30);
            this.labelX01.Name = "labelX01";
            this.labelX01.Size = new System.Drawing.Size(143, 20);
            this.labelX01.TabIndex = 0;
            this.labelX01.Text = "Sỉ số tối thiểu trong một lớp:";
            // 
            // tabItemSiSo
            // 
            this.tabItemSiSo.AttachedControl = this.tabControlPanelSiSo;
            this.tabItemSiSo.Name = "tabItemSiSo";
            this.tabItemSiSo.Text = "Sỉ số";
            // 
            // tabControlPanelTruong
            // 
            this.tabControlPanelTruong.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.tabControlPanelTruong.Controls.Add(this.txtDiaChiTruong);
            this.tabControlPanelTruong.Controls.Add(this.txtTenTruong);
            this.tabControlPanelTruong.Controls.Add(this.labelX07);
            this.tabControlPanelTruong.Controls.Add(this.labelX06);
            this.tabControlPanelTruong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanelTruong.Location = new System.Drawing.Point(0, 23);
            this.tabControlPanelTruong.Name = "tabControlPanelTruong";
            this.tabControlPanelTruong.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanelTruong.Size = new System.Drawing.Size(344, 125);
            this.tabControlPanelTruong.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tabControlPanelTruong.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tabControlPanelTruong.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanelTruong.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanelTruong.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanelTruong.Style.GradientAngle = 90;
            this.tabControlPanelTruong.TabIndex = 0;
            this.tabControlPanelTruong.TabItem = this.tabItemTruong;
            // 
            // txtDiaChiTruong
            // 
            // 
            // 
            // 
            this.txtDiaChiTruong.Border.Class = "TextBoxBorder";
            this.txtDiaChiTruong.Location = new System.Drawing.Point(100, 70);
            this.txtDiaChiTruong.Name = "txtDiaChiTruong";
            this.txtDiaChiTruong.Size = new System.Drawing.Size(210, 20);
            this.txtDiaChiTruong.TabIndex = 2;
            // 
            // txtTenTruong
            // 
            // 
            // 
            // 
            this.txtTenTruong.Border.Class = "TextBoxBorder";
            this.txtTenTruong.Location = new System.Drawing.Point(100, 30);
            this.txtTenTruong.Name = "txtTenTruong";
            this.txtTenTruong.Size = new System.Drawing.Size(210, 20);
            this.txtTenTruong.TabIndex = 1;
            // 
            // labelX07
            // 
            this.labelX07.BackColor = System.Drawing.Color.Transparent;
            this.labelX07.Location = new System.Drawing.Point(30, 70);
            this.labelX07.Name = "labelX07";
            this.labelX07.Size = new System.Drawing.Size(64, 20);
            this.labelX07.TabIndex = 0;
            this.labelX07.Text = "Địa chỉ:";
            // 
            // labelX06
            // 
            this.labelX06.BackColor = System.Drawing.Color.Transparent;
            this.labelX06.Location = new System.Drawing.Point(30, 30);
            this.labelX06.Name = "labelX06";
            this.labelX06.Size = new System.Drawing.Size(64, 20);
            this.labelX06.TabIndex = 0;
            this.labelX06.Text = "Tên trường:";
            // 
            // tabItemTruong
            // 
            this.tabItemTruong.AttachedControl = this.tabControlPanelTruong;
            this.tabItemTruong.Name = "tabItemTruong";
            this.tabItemTruong.Text = "Thông tin Trường";
            // 
            // tabControlPanelThangDiem
            // 
            this.tabControlPanelThangDiem.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.tabControlPanelThangDiem.Controls.Add(this.ckbThang100);
            this.tabControlPanelThangDiem.Controls.Add(this.ckbThang10);
            this.tabControlPanelThangDiem.Controls.Add(this.labelX05);
            this.tabControlPanelThangDiem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanelThangDiem.Location = new System.Drawing.Point(0, 23);
            this.tabControlPanelThangDiem.Name = "tabControlPanelThangDiem";
            this.tabControlPanelThangDiem.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanelThangDiem.Size = new System.Drawing.Size(344, 125);
            this.tabControlPanelThangDiem.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tabControlPanelThangDiem.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tabControlPanelThangDiem.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanelThangDiem.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanelThangDiem.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanelThangDiem.Style.GradientAngle = 90;
            this.tabControlPanelThangDiem.TabIndex = 0;
            this.tabControlPanelThangDiem.TabItem = this.tabItemThangDiem;
            // 
            // ckbThang100
            // 
            this.ckbThang100.BackColor = System.Drawing.Color.Transparent;
            this.ckbThang100.CheckBoxStyle = DevComponents.DotNetBar.eCheckBoxStyle.RadioButton;
            this.ckbThang100.Location = new System.Drawing.Point(30, 70);
            this.ckbThang100.Name = "ckbThang100";
            this.ckbThang100.Size = new System.Drawing.Size(116, 23);
            this.ckbThang100.TabIndex = 2;
            this.ckbThang100.Text = "Thang điểm 100";
            // 
            // ckbThang10
            // 
            this.ckbThang10.BackColor = System.Drawing.Color.Transparent;
            this.ckbThang10.CheckBoxStyle = DevComponents.DotNetBar.eCheckBoxStyle.RadioButton;
            this.ckbThang10.Location = new System.Drawing.Point(30, 45);
            this.ckbThang10.Name = "ckbThang10";
            this.ckbThang10.Size = new System.Drawing.Size(116, 23);
            this.ckbThang10.TabIndex = 1;
            this.ckbThang10.Text = "Thang điểm 10";
            // 
            // labelX05
            // 
            this.labelX05.BackColor = System.Drawing.Color.Transparent;
            this.labelX05.Location = new System.Drawing.Point(30, 20);
            this.labelX05.Name = "labelX05";
            this.labelX05.Size = new System.Drawing.Size(280, 20);
            this.labelX05.TabIndex = 0;
            this.labelX05.Text = "Thang điểm sử dụng để đánh giá kết quả học tập là:";
            // 
            // tabItemThangDiem
            // 
            this.tabItemThangDiem.AttachedControl = this.tabControlPanelThangDiem;
            this.tabItemThangDiem.Name = "tabItemThangDiem";
            this.tabItemThangDiem.Text = "Thang điểm";
            // 
            // tabControlPanelDoTuoi
            // 
            this.tabControlPanelDoTuoi.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.tabControlPanelDoTuoi.Controls.Add(this.txtDoTuoiCanTren);
            this.tabControlPanelDoTuoi.Controls.Add(this.labelX04);
            this.tabControlPanelDoTuoi.Controls.Add(this.txtDoTuoiCanDuoi);
            this.tabControlPanelDoTuoi.Controls.Add(this.labelX03);
            this.tabControlPanelDoTuoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanelDoTuoi.Location = new System.Drawing.Point(0, 23);
            this.tabControlPanelDoTuoi.Name = "tabControlPanelDoTuoi";
            this.tabControlPanelDoTuoi.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanelDoTuoi.Size = new System.Drawing.Size(344, 125);
            this.tabControlPanelDoTuoi.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(254)))));
            this.tabControlPanelDoTuoi.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(157)))), ((int)(((byte)(188)))), ((int)(((byte)(227)))));
            this.tabControlPanelDoTuoi.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanelDoTuoi.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(165)))), ((int)(((byte)(199)))));
            this.tabControlPanelDoTuoi.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanelDoTuoi.Style.GradientAngle = 90;
            this.tabControlPanelDoTuoi.TabIndex = 0;
            this.tabControlPanelDoTuoi.TabItem = this.tabItemDoTuoi;
            // 
            // txtDoTuoiCanTren
            // 
            // 
            // 
            // 
            this.txtDoTuoiCanTren.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDoTuoiCanTren.Location = new System.Drawing.Point(190, 70);
            this.txtDoTuoiCanTren.MaxValue = 40;
            this.txtDoTuoiCanTren.MinValue = 10;
            this.txtDoTuoiCanTren.Name = "txtDoTuoiCanTren";
            this.txtDoTuoiCanTren.ShowUpDown = true;
            this.txtDoTuoiCanTren.Size = new System.Drawing.Size(120, 20);
            this.txtDoTuoiCanTren.TabIndex = 2;
            this.txtDoTuoiCanTren.Value = 10;
            // 
            // labelX04
            // 
            this.labelX04.BackColor = System.Drawing.Color.Transparent;
            this.labelX04.Location = new System.Drawing.Point(30, 70);
            this.labelX04.Name = "labelX04";
            this.labelX04.Size = new System.Drawing.Size(154, 20);
            this.labelX04.TabIndex = 0;
            this.labelX04.Text = "Độ tuổi tối đa của học sinh:";
            // 
            // txtDoTuoiCanDuoi
            // 
            // 
            // 
            // 
            this.txtDoTuoiCanDuoi.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtDoTuoiCanDuoi.Location = new System.Drawing.Point(190, 30);
            this.txtDoTuoiCanDuoi.MaxValue = 40;
            this.txtDoTuoiCanDuoi.MinValue = 10;
            this.txtDoTuoiCanDuoi.Name = "txtDoTuoiCanDuoi";
            this.txtDoTuoiCanDuoi.ShowUpDown = true;
            this.txtDoTuoiCanDuoi.Size = new System.Drawing.Size(120, 20);
            this.txtDoTuoiCanDuoi.TabIndex = 1;
            this.txtDoTuoiCanDuoi.Value = 10;
            // 
            // labelX03
            // 
            this.labelX03.BackColor = System.Drawing.Color.Transparent;
            this.labelX03.Location = new System.Drawing.Point(30, 30);
            this.labelX03.Name = "labelX03";
            this.labelX03.Size = new System.Drawing.Size(154, 20);
            this.labelX03.TabIndex = 0;
            this.labelX03.Text = "Độ tuổi tối thiểu của học sinh:";
            // 
            // tabItemDoTuoi
            // 
            this.tabItemDoTuoi.AttachedControl = this.tabControlPanelDoTuoi;
            this.tabItemDoTuoi.Name = "tabItemDoTuoi";
            this.tabItemDoTuoi.Text = "Độ tuổi";
            // 
            // btnDongY
            // 
            this.btnDongY.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnDongY.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnDongY.Location = new System.Drawing.Point(164, 10);
            this.btnDongY.Name = "btnDongY";
            this.btnDongY.Size = new System.Drawing.Size(70, 23);
            this.btnDongY.TabIndex = 3;
            this.btnDongY.Text = "Đồng ý";
            this.btnDongY.Click += new System.EventHandler(this.btnDongY_Click);
            // 
            // btnHuyBo
            // 
            this.btnHuyBo.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnHuyBo.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnHuyBo.Location = new System.Drawing.Point(240, 10);
            this.btnHuyBo.Name = "btnHuyBo";
            this.btnHuyBo.Size = new System.Drawing.Size(70, 23);
            this.btnHuyBo.TabIndex = 4;
            this.btnHuyBo.Text = "Hủy bỏ";
            this.btnHuyBo.Click += new System.EventHandler(this.btnHuyBo_Click);
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.btnDongY);
            this.panelBottom.Controls.Add(this.btnHuyBo);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 148);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(344, 40);
            this.panelBottom.TabIndex = 1;
            // 
            // frmQuyDinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 188);
            this.Controls.Add(this.tabControlQuyDinh);
            this.Controls.Add(this.panelBottom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQuyDinh";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUY ĐỊNH";
            this.Load += new System.EventHandler(this.frmQuyDinh_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tabControlQuyDinh)).EndInit();
            this.tabControlQuyDinh.ResumeLayout(false);
            this.tabControlPanelSiSo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtSiSoCanTren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSiSoCanDuoi)).EndInit();
            this.tabControlPanelTruong.ResumeLayout(false);
            this.tabControlPanelThangDiem.ResumeLayout(false);
            this.tabControlPanelDoTuoi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtDoTuoiCanTren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDoTuoiCanDuoi)).EndInit();
            this.panelBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.TabControl tabControlQuyDinh;
        private DevComponents.Editors.IntegerInput txtSiSoCanDuoi;
        private DevComponents.DotNetBar.LabelX labelX01;
        private DevComponents.Editors.IntegerInput txtSiSoCanTren;
        private DevComponents.DotNetBar.LabelX labelX02;
        private DevComponents.DotNetBar.ButtonX btnHuyBo;
        private DevComponents.DotNetBar.ButtonX btnDongY;
        private System.Windows.Forms.Panel panelBottom;
        private DevComponents.Editors.IntegerInput txtDoTuoiCanDuoi;
        private DevComponents.Editors.IntegerInput txtDoTuoiCanTren;
        private DevComponents.DotNetBar.LabelX labelX04;
        private DevComponents.DotNetBar.LabelX labelX03;
        private DevComponents.DotNetBar.Controls.CheckBoxX ckbThang100;
        private DevComponents.DotNetBar.Controls.CheckBoxX ckbThang10;
        private DevComponents.DotNetBar.LabelX labelX05;
        private DevComponents.DotNetBar.Controls.TextBoxX txtDiaChiTruong;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTenTruong;
        private DevComponents.DotNetBar.LabelX labelX07;
        private DevComponents.DotNetBar.LabelX labelX06;
        private DevComponents.DotNetBar.TabItem tabItemSiSo;
        private DevComponents.DotNetBar.TabItem tabItemTruong;
        private DevComponents.DotNetBar.TabItem tabItemThangDiem;
        private DevComponents.DotNetBar.TabItem tabItemDoTuoi;
        public DevComponents.DotNetBar.TabControlPanel tabControlPanelSiSo;
        public DevComponents.DotNetBar.TabControlPanel tabControlPanelTruong;
        public DevComponents.DotNetBar.TabControlPanel tabControlPanelThangDiem;
        public DevComponents.DotNetBar.TabControlPanel tabControlPanelDoTuoi;
    }
}